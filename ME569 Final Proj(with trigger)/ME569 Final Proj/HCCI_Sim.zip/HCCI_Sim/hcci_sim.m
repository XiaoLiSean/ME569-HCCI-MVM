close all; clc;
clear all;
%% HCCI Eng. Model parameters
load_param;

%% Default Running Condition;
N       = 1000; % Fixed engine speed, rpm
Wf      = ???; % Constant fuel injection rate, g/sec
AFR_s   = 20; % Stoichiometry AFR
u_rbl   = ??? % Rebreathing valve lift, mm
tau     = 120 / N; % Engine cycle delay, sec
tau_EGO = ???; % EGO sensor time constant, sec;
%% Orifice specification A01 A20 A21 are unknow for now...
C_d     = ???; % Contraction coefficient
A01     = ???; % Calibrated throttle orifice
A20     = ???; % Calibrated exhaust orifice
A21     = ???; % Calibrated eEGR valve orifice
