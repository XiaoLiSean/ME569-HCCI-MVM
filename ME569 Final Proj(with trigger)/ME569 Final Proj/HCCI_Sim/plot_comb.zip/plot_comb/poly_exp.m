function [T_evo, p_evo] = expansion(T_ac, p_ac, theta_c)
%% Params for Arrhenius Integral & Combustion
%% Arrhenius Intergral Params
A           = 3570e-5; % Arrhenius scaling constant
n           = 1.35; % reaction��s sensitivity to pressure REF2[10]
Ea          = 6317; % Arrhenius activation energy
R           = 296.25; % gas constant, J/KgK
%% Combustion Duration Params
bk0         = 0.162; % const term in k parametrization 
bk1         = 0.005; % Linear term in k dependence on theta_soc 
bk2         = 0.001; % Square term in k dependence on theta_soc

a0          = 1.0327; % Constant term in e parametrization 
a1          = -5.45; % Linear term, e dependence on k 

c_v          = 1.4; % constant volume specific heat (KJ/Kg.K) [17]
Q_LHV       = 43960; % low heating value of the fuel (KJ/Kg)

Ec          = 185; % Activation energy, kJ/mol
Ru          = 8.314; % Universal gas constant, J/mol K
nc          = 1.30; % Polytropic constant during compression
ne          = 1.35; % Polytropic constant during expansion

dT_bd       = -65; % Blowdown temperature difference   
%% Load params for cylinder
%% Params for cylinder
V_d         = 5.5e-4; % Stroke (displacement) Volume, m^3
CR          = 14; % Cylinder compression ratio
V_TDC        = V_d / (CR - 1); % Vc when piston at TDC, m^3
%% Params for cylinder (Calculated)
B           = 8.6e-2; % Bore Diameter, m
r           = 2*V_d/(pi*B^2); % Crankshaft radius, m
rod_ratio   = 1.54; % GM L61 Ecotec Engine (2.2L);
l           = rod_ratio*2*r; % Connecting rod length
%% Solve theta_soc
syms theta T;
s           = r*(1-cos(theta)+l/r*(1-sqrt(1-(r*sin(theta)/l)^2))); % stroke, m
Vc          = V_TDC + s*pi*B^2/4;

theta_ivc   = -140*pi/180; % Crank angle at IVC, rad (Fig. 5)
theta_evo   = 130*pi/180; % Crank angle at EVO, rad (Fig. 5)
V_c       = double(subs(Vc, theta, theta_c));% Cylinder Volume of Intake Valve Closing (DBC), m^3
%% Calculation
T_evo        = T_ac*double(subs(V_c/Vc, theta, theta_evo))^(ne-1);
p_evo        = p_ac*double(subs(V_c/Vc, theta, theta_evo))^ne;
end