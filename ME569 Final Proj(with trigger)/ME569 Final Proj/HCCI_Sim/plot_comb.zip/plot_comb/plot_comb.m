clear all;
clc; close all;
%% Params for Arrhenius Integral & Combustion
combustion_param;
%% Load params for cylinder
load_eng;

AFR_c       = 20;
p_ivc       = 1.01e5;
T_ivc       = 450;
b_c         = 0.5;
p_2         = 9.8e5;
[theta_soc, T_soc] = AR_solver(p_ivc, T_ivc);
[theta_c, Delta_T, CA50, Tm] = comb_dur(b_c, AFR_c, theta_soc, T_soc);
[T_ac, p_ac] = heat_release(b_c, theta_c, Delta_T, p_ivc, T_ivc);
[T_evo, p_evo] = poly_exp(T_ac, p_ac, theta_c);
T_bd        = T_evo*(p_2/p_evo)^((ne-1)/ne) + dT_bd;

plot([theta_ivc theta_soc theta_c theta_c theta_evo theta_evo]*180/pi, [T_ivc T_soc Tm T_ac T_evo T_bd],'o');